// Uncomment these imports to begin using these cool features!

// import {inject} from '@loopback/core';


export class AlignmentController {
  constructor() {}
}
